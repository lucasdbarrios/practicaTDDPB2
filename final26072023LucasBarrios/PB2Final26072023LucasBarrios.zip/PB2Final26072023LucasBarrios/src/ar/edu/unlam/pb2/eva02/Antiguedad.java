package ar.edu.unlam.pb2.eva02;

public class Antiguedad extends Articulo {
	
	

	public Antiguedad(Integer codigoProducto, String nombre, Integer valor, String descripcion, Integer cantidad, TipoArticulo tipo) {
		super(codigoProducto,nombre,valor,descripcion,cantidad,tipo);
	}

}
