package ar.edu.unlam.pb2.eva02;

public class Venta {
	
//	private List<Combo> combovendido;

}
