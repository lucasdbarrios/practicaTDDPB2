package ar.edu.unlam.pb2.eva02;

public class Invaluable extends Articulo {

	public Invaluable(Integer codigoProducto, String nombre, Integer valor, String descripcion, Integer cantidad,
			TipoArticulo tipo) {
		super(codigoProducto, nombre, valor, descripcion, cantidad, tipo);
		// TODO Auto-generated constructor stub
	}

	
}
