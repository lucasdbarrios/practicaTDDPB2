package ar.edu.unlam.pb2.eva02;

public interface Comprar {

	public void comprarArticulos();
}
