package ar.edu.unlam.pb2.eva02;

public enum TipoArticulo {
	ANTIGUEDAD, DELUJO, EXOTICO, INVALUABLE
}
